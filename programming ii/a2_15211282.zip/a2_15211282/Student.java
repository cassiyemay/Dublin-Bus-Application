package a2_15211282;


public class Student extends Person{
	private String programme;
	private Module[] 
		modules;
	private static final int MAX_NUMBER_MODULES =12;
	
	public Student(){
		modules = new Module[MAX_NUMBER_MODULES];
	}
	
	public Student(Name name, Address address,String programme){
		super(name,address);
		modules = new Module[MAX_NUMBER_MODULES];
		this.programme=programme;
	}
	
	public String getProgramme(){
		return programme;
	}
	
	public boolean addModule(Module m){
		for (int i =0; i<modules.length;i++){
			if (modules[i] == null){
				modules[i]=m;
				break;}
			}
		return true;
	}
	
	@Override
	public String toString(){
		if (modules[0]==null)
			return super.toString() +
				"\nprogramme: "+ programme +
				"\nmodules: " +"\n\tnone"+"\n";
			
		else{
		String codetitle = "";
		for(int i=0;i<modules.length;i++){
			if(modules[i] != null)
				codetitle += "\n\t" + modules[i].getCode() + " ("+ modules[i].getTitle() +")";
			else
				break;
		}
		return super.toString() +
					"\nprogramme: "+ programme +
					"\nmodules: " + codetitle+"\n";
	}
}
	
}