package a2_15211282;

public class Module{
	private String code;
	private String title;
	private Instructor instructor;
	private Student[] students;
	private static final int MAX_NUMBER_STUDENTS =80;
	
	public Module(){
		this.code = "";
		this.title="";
	}
	
	public Module(String code, String title){
		this.code=code;
		this.title=title;
		students=new Student[MAX_NUMBER_STUDENTS];
	}
	
	public String getCode(){
		return code;
	}
	
	public String getTitle(){
		return title;
	}
	
	public Instructor getInstructor(){
		return instructor;
	}
	
	public void setInstructor(Instructor instructor){
		this.instructor=instructor;
	}
	
	public boolean addStudent(Student s){
		for(int i=0;i<students.length;i++){
			if(students[i]==null){
				students[i]=s;
				break;
				}
			}
		for(int j=0;j<students.length;j++){
			for(int k=0;k<students.length;k++){
				if (students[j]==students[k])
					return false;
			}
		}	
		return true;
			}
	
	@Override
	public String toString(){
		String studentlist="";
		for (int i=0; i< students.length;i++){
			if(students[i] !=null)
				studentlist += "\n\t" + students[i].getName();
			else
				break;
			}
		
		if(students[0]==null && instructor ==null)
		return "\ncode: " + code + 
				"\ntitle: " + title +
				"\ninstructor: " + "not set"+
				"\nstudents: " +"\n\tnone" +"\n" ;
		
		else if(students !=null && instructor ==null)
			return "\ncode: " + code + 
					"\ntitle: " + title +
					"\ninstructor: " + "not set"+
					"\nstudents: " +studentlist +"\n";
		
		else if (students[0] ==null && instructor !=null)
			return "\ncode: " + code + 
					"\ntitle: " + title +
					"\ninstructor: " + instructor.getName()+
					"\nstudents: " + "\n\tnone"+"\n";
		
		else
			return "\ncode: " + code + 
					"\ntitle: " + title +
					"\ninstructor: " + instructor.getName() +
					"\nstudents: "  +studentlist+"\n"
					;
	}}

