package a2_15211282;

public class Instructor extends Person{
	private String position;
	private Module module;
	
	public Instructor(){
	}
	
	public Instructor(Name name, Address address, String position){
		super(name,address);
		this.position=position;
	}
	
	public void setModule(Module module){
		this.module= module;
	}
	
	@Override
	public String toString(){
		if(module==null)
			return super.toString() +
					"\nposition: " + position+
					"\nmodule: " +"not set"+"\n";
		else
			return super.toString() +
				"\nposition: " +this.position+
				"\nmodule: " +module.getCode() + " ("+ module.getTitle() + ")"+"\n";			
	}
	
}