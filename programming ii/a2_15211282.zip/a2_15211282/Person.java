package a2_15211282;

public class Person{
	private Name name;
	private Address address;
	
	public Person(){
		 name = new Name(" "," ");
		 address = new Address(" "," "," ");
	}
	
	public Person(Name name, Address address){
		this.name=name;
		this.address=address;
	}
	
	public Name getName(){
		return name;
	}
	
	public Address getAddress(){
		return address;
	}
	
	public String toString(){
		return "\nname: " + name + 
				"\naddress: " + address;
	}
}


