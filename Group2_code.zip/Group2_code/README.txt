The following is group 2 GitHub address:

   https://github.com/DavyShawFTL/Summer-Project

In the folder named files on Server/FlaskApp, there are the all project code.
